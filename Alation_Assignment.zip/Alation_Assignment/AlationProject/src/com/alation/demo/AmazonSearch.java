package com.alation.demo;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.chrome.ChromeDriver;

import org.testng.annotations.AfterMethod;

import org.testng.annotations.BeforeMethod;

import org.testng.annotations.Test;

import org.testng.asserts.SoftAssert;

import org.openqa.selenium.support.ui.Select;

 
public class AmazonSearch

{

 WebDriver driver;

@BeforeMethod

public void beforeMethod()

{
//Set system property for Chrome Driver
System.setProperty("webdriver.chrome.driver","C://SeleniumProject/chromedriver.exe");

driver = new ChromeDriver();

driver.get("https://www.amazon.com/");

}

 

@Test

public void test1()

{
//Declare the drop-down element as an instance of the Select class. Here the instance is "drpAll". 
Select drpAll = new Select(driver.findElement(By.id("searchDropdownBox")));

//Select the "Books" option from the list of dropdown elements by using index
drpAll.selectByIndex(10);

//Enter the text "data catalog" as search criteria
driver.findElement(By.id("twotabsearchtextbox")).sendKeys("data catalog");

//Provide a wait before clicking search
driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

driver.findElement(By.xpath("//*[@id='nav-search']/form/div[2]/div/input")).click();

driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

//Click on the 1st product displayed other than promotional items
driver.findElement(By.id("pdagDesktopSparkleDescription1")).click();

//Get the title of the book
String book = driver.findElement(By.xpath("//*[@id='productTitle']")).getText();

//Get the author name of the book
String author = driver.findElement(By.xpath("//*[@id='bylineInfo']")).getText();

//Get the kindle edition and price of the book
String kindleEdition = driver.findElement(By.xpath("//*[@id='mediaTab_heading_0']")).getText();

//Get the paper edition and price of the book
String paperEdition = driver.findElement(By.xpath("//*[@id='mediaTab_heading_1']")).getText();

 
//Use Soft Assertion-Soft Assertion has been used to validate the book's name match with original one.
//Soft assertion doesnt halt further steps incase assertion fails.
//It will execute further steps and assertion. 
SoftAssert assertion = new SoftAssert();

assertion.assertEquals(book, "R for Everyone: Advanced Analytics and Graphics (2nd Edition) (Addison-Wesley Data & Analytics Series)");

assertion.assertAll();

//print all the details of the book
System.out.println("Book Name: "+book + "\n Written "+author + "\n Edition Type & Price: "+kindleEdition + "\n Edition Type & Price: "+paperEdition);

 

}

 
@AfterMethod

public void afterMethod()

{

driver.close();

}

}